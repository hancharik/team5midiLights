import org.junit.*;
import static org.junit.Assert.*;
//#import ;
	  

public class DataObjectJUnitTest
{
  //String [] strings = new String [4];
  // configure stuff here for later
  static studentprogramtester.controler.DataObject Target = null;
  @BeforeClass
  public static void setupTests()
  {
    System.out.println("Starting Tests");
	System.out.println("creating Object");
	Target = new studentprogramtester.controler.DataObject();
  }
  
  @Before
  public void setupTest()
  {
	 // this is run before each test  
	//this.strings[0] = "abc";
	//this.strings[1] = " ";
	//this.strings[2] = "1" + "2" + "3";
	//this.strings[3] = null;
	System.out.println("Test Starting");
  }
  
  @After 
  public void tearDownTest()
  {
	  System.out.println("Test Complete\n\n\n\n\n");
  }
  
  // Individual tests follow
  @Test
  public void createObjTest()
  {
	  // Arrange
	  this.setupTest();
	  // Act
	  
	  System.out.println("Check if not null");
	  assertNotNull("Our Object is null!",Target);
	  System.out.println("It's good\n");
	  System.out.println("Checking Object Type for " + Target.getClass().getName().toString());
	  assertTrue(Target.getClass().getName().toString().equals("studentprogramtester.controler.DataObject"));
	  System.out.println("It is the right type\n");
  }
  @Test
  public void checkNUmberValue()
  {
	  System.out.println("Checking the value of the student number");
	  assertEquals("Checking the number",0,Target.getNumbr());
	  System.out.println("Number was correct");
  }
} 
 