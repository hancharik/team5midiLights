public class Program
{
  public String concatenate(String stringOne, String stringTwo)
  {
    return stringOne + stringTwo;
  }
}